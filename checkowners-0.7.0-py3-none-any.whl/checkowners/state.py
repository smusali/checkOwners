"""Persistent state at ~/.checkowners/state/<repo-hash>.json.

The state file is the cache of the most recent analyze run for a repo.
Downstream commands (drift, decay, qualified-owners, topology, balance, onboard)
read from it to avoid re-running git log on every invocation. State is keyed
per repo (schema 1) by the normalized origin URL, or by the absolute path
when the repo has no origin. The payload records that identity and it is
checked on load.

Schema is versioned. Older state files are not auto-migrated; they are
ignored and a fresh state replaces them on the next analyze.
"""

from __future__ import annotations

import json
import re
import shutil
from collections.abc import Mapping
from dataclasses import asdict, dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from typing import NotRequired, TypedDict, TypeGuard, get_args

from checkowners import __version__
from checkowners.concentration import (
    distribution_json,
    owner_distribution,
    qualified_owner_count_fields,
)
from checkowners.config import (
    Config,
)
from checkowners.models import (
    GAP_CATALOG,
    AnalysisCompleteness,
    AnalysisGap,
    BusFactor,
    ConfidenceScore,
    ContributorStatus,
    DecayWarning,
    FreshnessStatus,
    GapCode,
    OwnerEntry,
    OwnershipEvidence,
    OwnershipFreshness,
    OwnershipMap,
    PathOwnership,
    ReportedMergeStrategy,
    Severity,
    SignalScore,
    TeamCluster,
    is_contributor_status,
)
from checkowners.privacy import stored_identity
from checkowners.providers import evidence_from_payload, evidence_payload
from checkowners.storage import (
    CACHE_LIMIT_BYTES,
    GRAPH_CACHE_SUBDIR,
    HANDLE_CACHE_SUBDIR,
    STATE_SUBDIR,
    atomic_write,
    base_dir,
    blame_cache_files,
    bounded_files,
    config_hash,
    file_size,
    graph_cache_path,
    handle_cache_files,
    json_files,
    locked,
    read_json,
    repo_digest,
    repository_identity,
    state_path,
)


@dataclass(frozen=True)
class BlameLines:
    blob_sha: str
    lines: dict[str, int]


@dataclass(frozen=True)
class PathMove:
    kind: str
    score: int
    source: str
    dest: str


@dataclass(frozen=True)
class HistoryBaseline:
    analysis_ref: str
    files: dict[str, tuple[str, ...]]
    modified: dict[str, int]
    renames: frozenset[str]
    blame: dict[str, BlameLines]
    blame_inputs: str
    rename_detection: str
    truncated: bool
    follow_renames: bool = True
    rename_similarity: int = 50
    moves: dict[str, tuple[PathMove, ...]] = field(default_factory=dict)


class CacheEntry(TypedDict):
    repo_id: str
    analysis_ref: str
    last_analyzed: str
    bytes: int


@dataclass(frozen=True)
class HandleCacheEntry:
    handle: str
    source: str = ""
    account_type: str = ""
    expires_at: str = ""


class CacheInfo(TypedDict):
    path: str
    bytes: int
    state_files: int
    graph_files: int
    handles: bool
    limit_bytes: int
    entries: list[CacheEntry]
    blame_files: int
    current_repo_id: NotRequired[str]
    current_state_path: NotRequired[str]
    current_state_exists: NotRequired[bool]


def _version_current(data: Mapping[str, object]) -> bool:
    return data.get("package_version") == __version__


def _resolved_config(config: Config | None) -> Config:
    return config if config is not None else Config()


def _identity_fields(repo_root: Path, config: Config | None) -> dict[str, object]:
    resolved = _resolved_config(config)
    return {
        "repo": str(repo_root.resolve()),
        "repo_id": repository_identity(repo_root),
        "config_hash": config_hash(resolved),
        "package_version": __version__,
    }


def _contributor_status(value: object) -> ContributorStatus:
    if isinstance(value, str) and is_contributor_status(value):
        return value
    return "unknown"


def _evict(keep: Path) -> None:
    files = bounded_files()
    total = sum(file_size(path) for path in files)
    if total <= CACHE_LIMIT_BYTES:
        return
    keep_resolved = keep.resolve()
    victims = [path for path in files if path.resolve() != keep_resolved]
    victims.sort(key=lambda path: path.stat().st_mtime if path.exists() else 0)
    for path in victims:
        if total <= CACHE_LIMIT_BYTES:
            break
        size = file_size(path)
        path.unlink(missing_ok=True)
        total -= size


def _string_field(data: dict[str, object] | None, key: str) -> str:
    if data is None:
        return ""
    value = data.get(key, "")
    return value if isinstance(value, str) else ""


def write_graph_cache(
    repo_root: Path,
    last_analyzed: datetime,
    graph_data: Mapping[str, object],
    *,
    config: Config | None = None,
    analysis_ref: str = "",
) -> Path:
    """Persist a serialized ownership graph, tagged with the analysis timestamp.

    `config` selects the scoring hash stored beside the graph. `analysis_ref`
    is the commit the graph was built from. Returns the cache file path.
    """
    target = graph_cache_path(repo_root)
    payload = {
        **_identity_fields(repo_root, config),
        "last_analyzed": last_analyzed.astimezone(UTC).isoformat(),
        "analysis_ref": analysis_ref,
        "graph": _stored_graph(graph_data),
    }
    text = json.dumps(payload, indent=2, sort_keys=True)
    with locked(target):
        atomic_write(target, text)
        _evict(target)
    return target


def read_graph_cache(
    repo_root: Path,
    last_analyzed: datetime,
    *,
    config: Config | None = None,
    analysis_ref: str | None = None,
) -> dict[str, object] | None:
    """Return the cached graph when it matches this analysis, else None.

    `config`, when passed, must hash to the stored config hash. `analysis_ref`,
    when passed, must equal the stored commit. A timestamp mismatch also misses.
    """
    data = read_json(graph_cache_path(repo_root))
    if data is None or not _version_current(data):
        return None
    if data.get("repo_id") != repository_identity(repo_root):
        return None
    if data.get("last_analyzed") != last_analyzed.astimezone(UTC).isoformat():
        return None
    if config is not None and data.get("config_hash") != config_hash(config):
        return None
    if analysis_ref is not None and data.get("analysis_ref") != analysis_ref:
        return None
    graph = data.get("graph")
    return graph if isinstance(graph, dict) else None


def read_history_baseline(
    repo_root: Path,
    config: Config,
) -> tuple[HistoryBaseline | None, str]:
    """Return `(baseline, reason)` for `repo_root` and `config`.

    `reason` is empty when no baseline is stored.
    """
    data = read_json(state_path(repo_root))
    if data is None or "history" not in data:
        return None, ""
    reason = _baseline_rejection(data, repo_root, config)
    if reason:
        return None, reason
    parsed = _parse_history(data.get("history"))
    if parsed is None:
        return None, "incremental baseline is corrupt"
    return parsed, ""


def _baseline_rejection(data: Mapping[str, object], repo_root: Path, config: Config) -> str:
    if data.get("repo_id") != repository_identity(repo_root):
        return "repository identity changed"
    if data.get("config_hash") != config_hash(config):
        return "scoring configuration changed"
    if data.get("package_version") != __version__:
        return "package version changed"
    return ""


def _history_payload(
    history: HistoryBaseline | None,
    existing: Mapping[str, object] | None,
) -> object | None:
    if history is not None:
        return _serialize_history(history)
    if existing is None:
        return None
    stored = existing.get("history")
    if isinstance(stored, dict):
        return stored
    return None


def _serialize_history(baseline: HistoryBaseline) -> dict[str, object]:
    return {
        "analysis_ref": baseline.analysis_ref,
        "files": {sha: list(paths) for sha, paths in baseline.files.items()},
        "modified": dict(baseline.modified),
        "renames": sorted(baseline.renames),
        "blame": {
            path: {
                "blob_sha": item.blob_sha,
                "lines": dict(item.lines),
            }
            for path, item in baseline.blame.items()
        },
        "blame_inputs": baseline.blame_inputs,
        "rename_detection": baseline.rename_detection,
        "truncated": baseline.truncated,
        "follow_renames": baseline.follow_renames,
        "rename_similarity": baseline.rename_similarity,
        "moves": {
            sha: [
                {
                    "kind": move.kind,
                    "score": move.score,
                    "source": move.source,
                    "dest": move.dest,
                }
                for move in moves
            ]
            for sha, moves in baseline.moves.items()
        },
    }


def _parse_history(raw: object) -> HistoryBaseline | None:
    if not isinstance(raw, dict):
        return None
    ref = raw.get("analysis_ref")
    files = _parse_path_lists(raw.get("files"))
    modified = _parse_count_map(raw.get("modified"))
    renames = _parse_string_set(raw.get("renames"))
    blame = _parse_blame_map(raw.get("blame"))
    blame_inputs = raw.get("blame_inputs")
    rename_detection = raw.get("rename_detection")
    truncated = raw.get("truncated")
    if (
        not isinstance(ref, str)
        or files is None
        or modified is None
        or renames is None
        or blame is None
        or not isinstance(blame_inputs, str)
        or not isinstance(rename_detection, str)
        or not isinstance(truncated, bool)
    ):
        return None
    if "follow_renames" not in raw or "rename_similarity" not in raw:
        follow_renames = True
        rename_similarity = -1
        moves: dict[str, tuple[PathMove, ...]] = {}
    else:
        follow_renames_raw = raw.get("follow_renames")
        similarity_raw = raw.get("rename_similarity")
        parsed_moves = _parse_moves(raw.get("moves", {}))
        if (
            not isinstance(follow_renames_raw, bool)
            or isinstance(similarity_raw, bool)
            or not isinstance(similarity_raw, int)
            or parsed_moves is None
            or similarity_raw < -1
            or similarity_raw == 0
            or similarity_raw > 100
        ):
            return None
        follow_renames = follow_renames_raw
        rename_similarity = similarity_raw
        moves = parsed_moves
    return HistoryBaseline(
        analysis_ref=ref,
        files=files,
        modified=modified,
        renames=renames,
        blame=blame,
        blame_inputs=blame_inputs,
        rename_detection=rename_detection,
        truncated=truncated,
        follow_renames=follow_renames,
        rename_similarity=rename_similarity,
        moves=moves,
    )


def _parse_moves(raw: object) -> dict[str, tuple[PathMove, ...]] | None:
    if not isinstance(raw, dict):
        return None
    moves: dict[str, tuple[PathMove, ...]] = {}
    for sha, items in raw.items():
        if not isinstance(sha, str) or not isinstance(items, list):
            return None
        parsed: list[PathMove] = []
        for item in items:
            if not isinstance(item, dict):
                return None
            kind = item.get("kind")
            score = item.get("score")
            source = item.get("source")
            dest = item.get("dest")
            if kind not in {"R", "C", "D"} or isinstance(score, bool) or not isinstance(score, int):
                return None
            if not isinstance(source, str) or not isinstance(dest, str):
                return None
            if score < 0 or score > 100:
                return None
            parsed.append(PathMove(kind=kind, score=score, source=source, dest=dest))
        moves[sha] = tuple(parsed)
    return moves


def _parse_path_lists(raw: object) -> dict[str, tuple[str, ...]] | None:
    if not isinstance(raw, dict):
        return None
    files: dict[str, tuple[str, ...]] = {}
    for sha, paths in raw.items():
        if not isinstance(sha, str) or not isinstance(paths, list):
            return None
        cleaned: list[str] = []
        for path in paths:
            if not isinstance(path, str):
                return None
            cleaned.append(path)
        files[sha] = tuple(cleaned)
    return files


def _parse_count_map(raw: object) -> dict[str, int] | None:
    if not isinstance(raw, dict):
        return None
    counts: dict[str, int] = {}
    for key, value in raw.items():
        if not isinstance(key, str) or isinstance(value, bool) or not isinstance(value, int):
            return None
        if value < 0:
            return None
        counts[key] = value
    return counts


def _parse_string_set(raw: object) -> frozenset[str] | None:
    if not isinstance(raw, list):
        return None
    values: list[str] = []
    for item in raw:
        if not isinstance(item, str):
            return None
        values.append(item)
    return frozenset(values)


def _parse_blame_map(raw: object) -> dict[str, BlameLines] | None:
    if not isinstance(raw, dict):
        return None
    blame: dict[str, BlameLines] = {}
    for path, item in raw.items():
        if not isinstance(path, str) or not isinstance(item, dict):
            return None
        blob = item.get("blob_sha")
        lines = _parse_count_map(item.get("lines"))
        if not isinstance(blob, str) or not blob or lines is None:
            return None
        blame[path] = BlameLines(blob_sha=blob, lines=lines)
    return blame


def read_state(repo_root: Path) -> dict[str, object] | None:
    """Read a repo's state as a dict, or None if missing or structurally invalid."""
    data = read_json(state_path(repo_root))
    if data is None:
        return None
    if not _version_current(data):
        return None
    if data.get("repo_id") != repository_identity(repo_root):
        return None
    return data


def write_state(
    repo_root: Path,
    ownership: OwnershipMap,
    *,
    topology: tuple[TeamCluster, ...] = (),
    bus_factor_summary: tuple[BusFactor, ...] = (),
    drift_detected: bool = False,
    qualified_owner_count_cap: int = 3,
    drift_reported_severity: str | None = None,
    drift_pending_severity: str | None = None,
    drift_pending_streak: int = 0,
    config: Config | None = None,
    history: HistoryBaseline | None = None,
) -> Path:
    """Persist the latest ownership map and derived intelligence to disk.

    `config` selects the scoring hash stored with the map. When omitted, the
    default config is hashed. `history`, when passed, replaces the stored
    commit baseline. When omitted, an existing baseline is kept. Returns the
    state file path.
    """
    target = state_path(repo_root)
    with locked(target):
        existing = read_state(repo_root)
        if drift_reported_severity is None and existing is not None:
            prior_reported = existing.get("drift_reported_severity")
            prior_pending = existing.get("drift_pending_severity")
            prior_streak = existing.get("drift_pending_streak", 0)
            drift_reported_severity = prior_reported if isinstance(prior_reported, str) else None
            drift_pending_severity = prior_pending if isinstance(prior_pending, str) else None
            drift_pending_streak = prior_streak if isinstance(prior_streak, int) else 0
        payload: dict[str, object] = {
            **_identity_fields(repo_root, config),
            "inferred": {
                path: _serialize_path(po, qualified_owner_count_cap)
                for path, po in sorted(ownership.paths.items())
            },
            "topology": {"clusters": [_serialize_cluster(cluster) for cluster in topology]},
            "bus_factor_summary": _serialize_bus_factor_summary(
                bus_factor_summary,
                qualified_owner_count_cap,
                ownership,
                config if config is not None else Config(),
            ),
            "qualified_owner_count_cap": qualified_owner_count_cap,
            "last_analyzed": ownership.last_analyzed.astimezone(UTC).isoformat(),
            "analysis_ref": ownership.analysis_ref,
            "reviews_sampled": ownership.reviews_sampled,
            "reviews_window_days": ownership.reviews_window_days,
            "analysis_completeness": {
                "ignore_revs_applied": ownership.analysis_completeness.ignore_revs_applied,
                "ignore_revs_file": ownership.analysis_completeness.ignore_revs_file,
                "mailmap_applied": ownership.analysis_completeness.mailmap_applied,
                "mailmap_file": ownership.analysis_completeness.mailmap_file,
                "excluded_gitattributes": ownership.analysis_completeness.excluded_gitattributes,
                "excluded_static": ownership.analysis_completeness.excluded_static,
                "merge_strategy": ownership.analysis_completeness.merge_strategy,
                "co_author_count": ownership.analysis_completeness.co_author_count,
                "score": ownership.analysis_completeness.score,
                "gaps": [
                    {"code": gap.code, "reason": gap.reason}
                    for gap in ownership.analysis_completeness.gaps
                ],
            },
            "drift_detected": drift_detected,
            "drift_reported_severity": drift_reported_severity,
            "drift_pending_severity": drift_pending_severity,
            "drift_pending_streak": drift_pending_streak,
        }
        stored_history = _history_payload(history, existing)
        if stored_history is not None:
            payload["history"] = stored_history
        atomic_write(target, json.dumps(payload, indent=2, sort_keys=True))
        _evict(target)
    return target


def handle_cache_path(repo_root: Path) -> Path:
    """Return the handle-cache file for `repo_root`."""
    return base_dir() / HANDLE_CACHE_SUBDIR / f"{repo_digest(repo_root)}.json"


def _handle_entry(value: object) -> HandleCacheEntry | None:
    if isinstance(value, str):
        if not value:
            return None
        return HandleCacheEntry(handle=value)
    if not isinstance(value, dict):
        return None
    handle = value.get("handle", "")
    source = value.get("source", "")
    account_type = value.get("account_type", "")
    expires_at = value.get("expires_at", "")
    if not isinstance(handle, str):
        return None
    if not isinstance(source, str):
        source = ""
    if not isinstance(account_type, str):
        account_type = ""
    if not isinstance(expires_at, str):
        expires_at = ""
    if not handle and not expires_at:
        return None
    return HandleCacheEntry(
        handle=handle,
        source=source,
        account_type=account_type,
        expires_at=expires_at,
    )


def _parse_handle_cache(
    data: Mapping[str, object] | None,
) -> tuple[dict[str, HandleCacheEntry], bool]:
    if data is None:
        return {}, False
    parsed: dict[str, HandleCacheEntry] = {}
    changed = False
    for key, value in data.items():
        token = stored_identity(key)
        if token != key:
            changed = True
        entry = _handle_entry(value)
        if entry is None:
            changed = True
            continue
        parsed[token] = entry
    return parsed, changed


def _dump_handle_cache(cache: Mapping[str, HandleCacheEntry]) -> dict[str, dict[str, str]]:
    payload: dict[str, dict[str, str]] = {}
    for key, entry in cache.items():
        record = {"handle": entry.handle}
        if entry.handle:
            if entry.source:
                record["source"] = entry.source
            if entry.account_type:
                record["account_type"] = entry.account_type
        elif entry.expires_at:
            record["expires_at"] = entry.expires_at
        payload[stored_identity(key)] = record
    return payload


def read_handle_cache(repo_root: Path) -> dict[str, HandleCacheEntry]:
    """Return cached handle hits and misses for `repo_root`."""
    target = handle_cache_path(repo_root)
    with locked(target):
        parsed, changed = _parse_handle_cache(read_json(target))
        if changed:
            atomic_write(target, json.dumps(_dump_handle_cache(parsed), indent=2, sort_keys=True))
        return parsed


def write_handle_cache(repo_root: Path, cache: Mapping[str, HandleCacheEntry]) -> Path:
    """Merge `cache` into the handle file for `repo_root` and return its path."""
    target = handle_cache_path(repo_root)
    with locked(target):
        current, _changed = _parse_handle_cache(read_json(target))
        current.update(_dump_entries(cache))
        atomic_write(target, json.dumps(_dump_handle_cache(current), indent=2, sort_keys=True))
    return target


def _dump_entries(cache: Mapping[str, HandleCacheEntry]) -> dict[str, HandleCacheEntry]:
    return {stored_identity(key): value for key, value in cache.items()}


def load_ownership(repo_root: Path) -> OwnershipMap | None:
    """Reconstruct a repo's OwnershipMap, or None if state is missing/invalid."""
    data = read_state(repo_root)
    if data is None:
        return None
    inferred = data.get("inferred")
    last_analyzed_raw = data.get("last_analyzed")
    if not isinstance(inferred, dict) or not isinstance(last_analyzed_raw, str):
        return None
    paths: dict[str, PathOwnership] = {}
    for path, raw in inferred.items():
        if not isinstance(raw, dict):
            continue
        path_ownership = _deserialize_path(raw)
        if path_ownership is None:
            continue
        paths[path] = path_ownership
    try:
        last_analyzed = datetime.fromisoformat(last_analyzed_raw)
    except ValueError:
        return None
    analysis_ref_raw = data.get("analysis_ref", "")
    analysis_ref = analysis_ref_raw if isinstance(analysis_ref_raw, str) else ""
    return OwnershipMap(
        paths=paths,
        last_analyzed=last_analyzed,
        analysis_ref=analysis_ref,
        analysis_completeness=_deserialize_completeness(data.get("analysis_completeness")),
        reviews_sampled=_nonnegative_int(data.get("reviews_sampled")),
        reviews_window_days=_nonnegative_int(data.get("reviews_window_days")),
    )


def reusable_ownership(
    repo_root: Path,
    config: Config,
    *,
    head: str,
    allow_stale: bool = False,
    max_age: int | None = None,
) -> OwnershipMap | None:
    """Return cached ownership when it is safe to reuse, else None.

    `head` is the current commit. The map is reused when `analysis_ref` equals
    `head`, or when `allow_stale` is true. `max_age` is a maximum age in
    seconds; `0` refuses every cached map. A config-hash mismatch returns None
    even when `allow_stale` is true.
    """
    data = read_state(repo_root)
    if data is None or data.get("config_hash") != config_hash(config):
        return None
    ownership = load_ownership(repo_root)
    if ownership is None:
        return None
    if max_age is not None and (max_age == 0 or _age_seconds(ownership.last_analyzed) > max_age):
        return None
    if ownership.analysis_ref == head or allow_stale:
        return ownership
    return None


def _age_seconds(last_analyzed: datetime) -> float:
    aware = last_analyzed if last_analyzed.tzinfo is not None else last_analyzed.replace(tzinfo=UTC)
    return (datetime.now(tz=UTC) - aware.astimezone(UTC)).total_seconds()


def cache_info(repo_root: Path | None = None) -> CacheInfo:
    """Return cache totals and, when `repo_root` is set, that repository's state file."""
    state_files = json_files(STATE_SUBDIR)
    graph_files = json_files(GRAPH_CACHE_SUBDIR)
    blame_files = blame_cache_files()
    handle_files = handle_cache_files()
    total = sum(
        file_size(path) for path in (*state_files, *graph_files, *blame_files, *handle_files)
    )
    entries: list[CacheEntry] = []
    for path in state_files:
        data = read_json(path)
        entries.append(
            {
                "repo_id": _string_field(data, "repo_id"),
                "analysis_ref": _string_field(data, "analysis_ref"),
                "last_analyzed": _string_field(data, "last_analyzed"),
                "bytes": file_size(path),
            }
        )
    info: CacheInfo = {
        "path": str(base_dir()),
        "bytes": total,
        "state_files": len(state_files),
        "graph_files": len(graph_files),
        "blame_files": len(blame_files),
        "handles": bool(handle_files),
        "limit_bytes": CACHE_LIMIT_BYTES,
        "entries": entries,
    }
    if repo_root is not None:
        current = state_path(repo_root)
        info["current_repo_id"] = repository_identity(repo_root)
        info["current_state_path"] = str(current)
        info["current_state_exists"] = current.is_file()
    return info


def cache_clear() -> int:
    """Delete state, graph, and blame JSON files. Return how many files were removed."""
    return _unlink_json(STATE_SUBDIR) + _unlink_json(GRAPH_CACHE_SUBDIR) + _clear_blame_cache()


def cache_purge() -> int:
    """Delete every file under the cache root, including handles.

    Returns how many files were removed. The cache root directory is kept.
    """
    base = base_dir()
    if not base.exists():
        return 0
    removed = 0
    for child in list(base.iterdir()):
        if child.is_dir() and not child.is_symlink():
            removed += sum(1 for path in child.rglob("*") if path.is_file())
            shutil.rmtree(child)
        else:
            child.unlink()
            removed += 1
    return removed


_DIGEST = re.compile(r"[0-9a-f]{64}")


def blame_cache_path(digest: str) -> Path:
    if _DIGEST.fullmatch(digest) is None:
        msg = "blame cache id is not a digest"
        raise ValueError(msg)
    return base_dir() / "blame" / digest[:2] / f"{digest}.json"


def _blame_line_counts(raw: object) -> dict[str, int] | None:
    if not isinstance(raw, dict):
        return None
    lines = raw.get("lines")
    if not isinstance(lines, dict):
        return None
    counts: dict[str, int] = {}
    for key, value in lines.items():
        if not isinstance(key, str) or isinstance(value, bool) or not isinstance(value, int):
            return None
        if value < 0:
            return None
        counts[key] = value
    return counts


def read_blame_cache(digest: str) -> dict[str, int] | None:
    path = blame_cache_path(digest)
    with locked(path):
        if not path.is_file():
            return None
        try:
            payload: object = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return None
    return _blame_line_counts(payload)


def write_blame_cache(digest: str, lines: Mapping[str, int]) -> None:
    path = blame_cache_path(digest)
    text = json.dumps(
        {"lines": dict(sorted(lines.items()))},
        separators=(",", ":"),
        sort_keys=True,
    )
    with locked(path):
        atomic_write(path, text)
    _evict(path)


def _clear_blame_cache() -> int:
    files = blame_cache_files()
    root = base_dir() / "blame"
    if root.is_dir():
        shutil.rmtree(root)
    return len(files)


def _unlink_json(subdir: str) -> int:
    removed = 0
    for path in json_files(subdir):
        path.unlink(missing_ok=True)
        removed += 1
    return removed


def load_hysteresis(repo_root: Path) -> tuple[Severity | None, Severity | None, int]:
    """Return persisted drift severity hysteresis, or first-run defaults."""
    data = read_state(repo_root)
    if data is None:
        return None, None, 0
    reported = _read_severity(data.get("drift_reported_severity"))
    pending = _read_severity(data.get("drift_pending_severity"))
    streak_raw = data.get("drift_pending_streak", 0)
    streak = streak_raw if isinstance(streak_raw, int) and not isinstance(streak_raw, bool) else 0
    return reported, pending, streak


def _read_severity(raw: object) -> Severity | None:
    if raw == "info":
        return "info"
    if raw == "low":
        return "low"
    if raw == "medium":
        return "medium"
    if raw == "high":
        return "high"
    if raw == "critical":
        return "critical"
    return None


def _stored_names(names: tuple[str, ...]) -> list[str]:
    return [stored_identity(name) for name in names]


def _serialize_cluster(cluster: TeamCluster) -> dict[str, object]:
    payload = asdict(cluster)
    payload["members"] = _stored_names(cluster.members)
    payload["affiliated_members"] = _stored_names(cluster.affiliated_members)
    return payload


def _stored_node_id(node_id: object) -> object:
    if not isinstance(node_id, str) or not node_id.startswith("contrib::"):
        return node_id
    handle = node_id.removeprefix("contrib::")
    return f"contrib::{stored_identity(handle)}"


def _stored_graph(graph_data: Mapping[str, object]) -> dict[str, object]:
    nodes = graph_data.get("nodes")
    edges = graph_data.get("edges")
    stored_nodes: list[dict[str, object]] = []
    if isinstance(nodes, list):
        for node in nodes:
            if not isinstance(node, dict):
                continue
            copied: dict[str, object] = {str(key): item for key, item in node.items()}
            copied["id"] = _stored_node_id(copied.get("id"))
            stored_nodes.append(copied)
    stored_edges: list[dict[str, object]] = []
    if isinstance(edges, list):
        for edge in edges:
            if not isinstance(edge, dict):
                continue
            copied = {str(key): item for key, item in edge.items()}
            copied["source"] = _stored_node_id(copied.get("source"))
            copied["target"] = _stored_node_id(copied.get("target"))
            stored_edges.append(copied)
    return {"nodes": stored_nodes, "edges": stored_edges}


def _serialize_path(po: PathOwnership, cap: int) -> dict[str, object]:
    payload: dict[str, object] = {
        "owners": [_serialize_owner(o) for o in po.owners],
        "scored_owners": [_serialize_owner(o) for o in po.scored_owners],
        **qualified_owner_count_fields(po.qualified_owner_count, cap),
        "decay_warnings": [_serialize_decay(w) for w in po.decay_warnings],
    }
    if po.change_events is not None:
        payload["change_events"] = po.change_events
    if po.cadence_days is not None:
        payload["cadence_days"] = po.cadence_days
    if po.cochange_degree is not None:
        payload["cochange_degree"] = po.cochange_degree
    if po.evidence:
        payload["evidence"] = [_serialize_evidence(record) for record in po.evidence]
    return payload


def _serialize_evidence(record: OwnershipEvidence) -> dict[str, str | float | int]:
    payload = evidence_payload(record)
    payload["subject"] = stored_identity(record.subject)
    payload["path"] = record.path
    return payload


def _serialize_owner(entry: OwnerEntry) -> dict[str, object]:
    payload: dict[str, object] = {
        "handle": stored_identity(entry.handle),
        "ownership_score": entry.ownership_score,
        "evidence_quality": entry.evidence_quality,
        "last_commit": entry.last_commit.astimezone(UTC).isoformat() if entry.last_commit else None,
        "commits": entry.commits,
        "contributor_status": entry.contributor_status,
    }
    if entry.score_breakdown is not None:
        payload["signals"] = entry.score_breakdown.signals_payload()
    if entry.freshness is not None:
        payload["freshness"] = _serialize_freshness(entry.freshness)
    return payload


def _serialize_freshness(freshness: OwnershipFreshness) -> dict[str, float | str]:
    return {
        "active_expertise": freshness.active_expertise,
        "historical_expertise": freshness.historical_expertise,
        "maintenance_recency": freshness.maintenance_recency,
        "status": freshness.status,
        "half_life_days": freshness.half_life_days,
    }


def _serialize_decay(warning: DecayWarning) -> dict[str, object]:
    return {
        "handle": stored_identity(warning.handle),
        "path": warning.path,
        "last_commit": warning.last_commit.astimezone(UTC).isoformat(),
        "days_since_last_commit": warning.days_since_last_commit,
        "historical_confidence": warning.historical_confidence,
        "status": warning.status,
    }


def _serialize_bus_factor_summary(
    entries: tuple[BusFactor, ...],
    cap: int,
    ownership: OwnershipMap,
    config: Config,
) -> dict[str, object]:
    critical_paths = sorted(e.path for e in entries if e.qualified_owner_count <= 1)
    distribution = owner_distribution(entries, ownership, config)
    serialized_entries: list[dict[str, object]] = []
    for entry in entries:
        row = asdict(entry)
        row["contributors_above_threshold"] = _stored_names(entry.contributors_above_threshold)
        row["recommended_backups"] = _stored_names(entry.recommended_backups)
        row.update(qualified_owner_count_fields(entry.qualified_owner_count, cap))
        serialized_entries.append(row)
    return {
        "critical_paths": critical_paths,
        "distribution": distribution_json(distribution),
        "qualified_owner_count_cap": cap,
        "entries": serialized_entries,
    }


def _deserialize_completeness(raw: object) -> AnalysisCompleteness:
    if not isinstance(raw, dict):
        return AnalysisCompleteness()
    applied = raw.get("ignore_revs_applied", False)
    path = raw.get("ignore_revs_file", "")
    mailmap_applied = raw.get("mailmap_applied", False)
    mailmap_file = raw.get("mailmap_file", "")
    excluded_gitattributes = raw.get("excluded_gitattributes", 0)
    excluded_static = raw.get("excluded_static", 0)
    merge_strategy = raw.get("merge_strategy", "rebase")
    co_author_count = raw.get("co_author_count", 0)
    return AnalysisCompleteness(
        ignore_revs_applied=applied is True,
        ignore_revs_file=path if isinstance(path, str) else "",
        mailmap_applied=mailmap_applied is True,
        mailmap_file=mailmap_file if isinstance(mailmap_file, str) else "",
        excluded_gitattributes=(
            excluded_gitattributes if isinstance(excluded_gitattributes, int) else 0
        ),
        excluded_static=excluded_static if isinstance(excluded_static, int) else 0,
        merge_strategy=(
            merge_strategy
            if isinstance(merge_strategy, str) and _is_reported_strategy(merge_strategy)
            else "rebase"
        ),
        co_author_count=_nonnegative_int(co_author_count),
        score=_optional_score(raw.get("score")),
        gaps=_deserialize_gaps(raw.get("gaps")),
    )


def _is_reported_strategy(value: str) -> TypeGuard[ReportedMergeStrategy]:
    return value in get_args(ReportedMergeStrategy)


def _nonnegative_int(raw: object) -> int:
    if isinstance(raw, bool) or not isinstance(raw, int) or raw < 0:
        return 0
    return raw


def _optional_score(raw: object) -> float | None:
    if isinstance(raw, bool) or raw is None:
        return None
    if isinstance(raw, int):
        return raw * 1.0
    if isinstance(raw, float):
        return raw
    return None


def _is_gap_code(value: str) -> bool:
    return value in GAP_CATALOG


def _deserialize_gaps(raw: object) -> tuple[AnalysisGap, ...]:
    if not isinstance(raw, list):
        return ()
    gaps: list[AnalysisGap] = []
    for item in raw:
        if not isinstance(item, dict):
            continue
        code = item.get("code")
        reason = item.get("reason")
        if not isinstance(code, str) or not isinstance(reason, str) or not _is_gap_code(code):
            continue
        gaps.append(AnalysisGap(code=_as_gap_code(code), reason=reason))
    return tuple(gaps)


def _as_gap_code(code: str) -> GapCode:
    for known in GAP_CATALOG:
        if known == code:
            return known
    msg = f"unknown gap code: {code}"
    raise ValueError(msg)


def _deserialize_owners(raw: object) -> tuple[OwnerEntry, ...]:
    if not isinstance(raw, list):
        return ()
    owners: list[OwnerEntry] = []
    for entry in raw:
        if not isinstance(entry, dict):
            continue
        deserialized = _deserialize_owner(entry)
        if deserialized is not None:
            owners.append(deserialized)
    return tuple(owners)


def _deserialize_path(raw: dict[str, object]) -> PathOwnership | None:
    if not isinstance(raw.get("owners"), list):
        return None
    owners = _deserialize_owners(raw.get("owners"))
    scored_owners = (
        _deserialize_owners(raw.get("scored_owners")) if "scored_owners" in raw else owners
    )
    qualified_owner_count = _read_qualified_owner_count(raw)
    raw_decay = raw.get("decay_warnings", [])
    decay_warnings: list[DecayWarning] = []
    if isinstance(raw_decay, list):
        for warning in raw_decay:
            if isinstance(warning, dict):
                deserialized_warning = _deserialize_decay(warning)
                if deserialized_warning is not None:
                    decay_warnings.append(deserialized_warning)
    return PathOwnership(
        owners=owners,
        qualified_owner_count=qualified_owner_count,
        decay_warnings=tuple(decay_warnings),
        scored_owners=scored_owners,
        change_events=_read_optional_int(raw.get("change_events")),
        cadence_days=_read_number(raw.get("cadence_days")),
        cochange_degree=_read_number(raw.get("cochange_degree")),
        evidence=_deserialize_evidence(raw.get("evidence")),
    )


def _deserialize_evidence(raw: object) -> tuple[OwnershipEvidence, ...]:
    if not isinstance(raw, list):
        return ()
    records: list[OwnershipEvidence] = []
    for item in raw:
        parsed = evidence_from_payload("", item)
        if parsed is not None:
            records.append(parsed)
    return tuple(records)


def _read_qualified_owner_count(raw: dict[str, object]) -> int:
    raw_count = raw.get("qualified_owner_count", 0)
    if isinstance(raw_count, bool) or not isinstance(raw_count, int):
        return 0
    return raw_count


def _deserialize_owner(raw: dict[str, object]) -> OwnerEntry | None:
    handle = raw.get("handle")
    score_raw = raw.get("ownership_score")
    quality_raw = raw.get("evidence_quality", 1.0)
    commits = raw.get("commits")
    last_commit_raw = raw.get("last_commit")
    if not isinstance(handle, str) or isinstance(score_raw, bool):
        return None
    if not isinstance(score_raw, int | float):
        return None
    if isinstance(quality_raw, bool) or not isinstance(quality_raw, int | float):
        return None
    if not isinstance(commits, int):
        return None
    last_commit: datetime | None
    if isinstance(last_commit_raw, str):
        try:
            last_commit = datetime.fromisoformat(last_commit_raw)
        except ValueError:
            last_commit = None
    else:
        last_commit = None
    score_breakdown = _deserialize_signals(raw.get("signals"), _number(score_raw))
    return OwnerEntry(
        handle=handle,
        ownership_score=_number(score_raw),
        last_commit=last_commit,
        commits=commits,
        evidence_quality=_number(quality_raw),
        score_breakdown=score_breakdown,
        freshness=_deserialize_freshness(raw.get("freshness")),
        contributor_status=_contributor_status(raw.get("contributor_status")),
    )


def _number(value: int | float) -> float:
    if isinstance(value, int):
        return value + 0.0
    return value


def _deserialize_signals(raw: object, total: float) -> ConfidenceScore | None:
    if not isinstance(raw, dict):
        return None
    recency = _read_signal(raw.get("recency"))
    frequency = _read_signal(raw.get("frequency"))
    blame = _read_signal(raw.get("blame"))
    review = _read_signal(raw.get("review"))
    if recency is None or frequency is None or blame is None or review is None:
        return None
    parsed_survival = _read_signal(raw.get("change_survival"))
    change_survival = (
        parsed_survival if parsed_survival is not None else SignalScore(available=False)
    )
    return ConfidenceScore(
        total=total,
        recency=recency,
        frequency=frequency,
        blame=blame,
        review=review,
        change_survival=change_survival,
    )


def _read_signal(raw: object) -> SignalScore | None:
    if not isinstance(raw, dict):
        return None
    available = raw.get("available")
    if not isinstance(available, bool):
        return None
    if not available:
        return SignalScore(available=False)
    score = raw.get("score", 0.0)
    if isinstance(score, bool) or not isinstance(score, int | float):
        return None
    return SignalScore(available=True, score=float(score))


_FRESHNESS_STATUSES: tuple[FreshnessStatus, ...] = (
    "inactive",
    "superseded",
    "stable",
    "departed",
)


def _match_freshness_status(value: object) -> FreshnessStatus | None:
    if not isinstance(value, str):
        return None
    for known in _FRESHNESS_STATUSES:
        if known == value:
            return known
    return None


def _read_freshness_status(value: object) -> FreshnessStatus:
    matched = _match_freshness_status(value)
    if matched is None:
        return "inactive"
    return matched


def _read_optional_int(value: object) -> int | None:
    if isinstance(value, bool) or not isinstance(value, int):
        return None
    return value


def _read_number(value: object) -> float | None:
    if isinstance(value, bool) or not isinstance(value, int | float):
        return None
    if isinstance(value, int):
        return value + 0.0
    return value


def _deserialize_freshness(raw: object) -> OwnershipFreshness | None:
    if not isinstance(raw, dict):
        return None
    active = _read_number(raw.get("active_expertise"))
    historical = _read_number(raw.get("historical_expertise"))
    maintenance = _read_number(raw.get("maintenance_recency"))
    half_life = _read_number(raw.get("half_life_days"))
    status = _match_freshness_status(raw.get("status"))
    if (
        active is None
        or historical is None
        or maintenance is None
        or half_life is None
        or status is None
    ):
        return None
    return OwnershipFreshness(
        active_expertise=active,
        historical_expertise=historical,
        maintenance_recency=maintenance,
        status=status,
        half_life_days=half_life,
    )


def _deserialize_decay(raw: dict[str, object]) -> DecayWarning | None:
    try:
        confidence = _read_number(raw.get("historical_confidence"))
        days = raw.get("days_since_last_commit")
        if confidence is None or isinstance(days, bool) or not isinstance(days, int):
            return None
        return DecayWarning(
            handle=str(raw["handle"]),
            path=str(raw["path"]),
            last_commit=datetime.fromisoformat(str(raw["last_commit"])),
            days_since_last_commit=days,
            historical_confidence=confidence,
            status=_read_freshness_status(raw.get("status")),
        )
    except (KeyError, TypeError, ValueError):
        return None
